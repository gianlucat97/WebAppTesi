package it.miglioramentoReportTest.model;

public class ReportTest {

	
	//Suppongo un solo caso di test per ogni test suite
		//Vedi struttura dati file excel "esiti Test"
		
		private String nomeTestSuite;
		private String releaseDiCreazione;
		private String locatoreUtilizzato;
		private Boolean esitoVerify_Hooks;
		private Boolean esitoTest;
		private String causaFallimento;
		
		
		public ReportTest() {
			super();
		}


		public ReportTest(String nomeTestSuite, String releaseDiCreazione, String locatoreUtilizzato,
				Boolean esitoVerify_Hooks, Boolean esitoTest, String causaFallimento) {
			super();
			this.nomeTestSuite = nomeTestSuite;
			this.releaseDiCreazione = releaseDiCreazione;
			this.locatoreUtilizzato = locatoreUtilizzato;
			this.esitoVerify_Hooks = esitoVerify_Hooks;
			this.esitoTest = esitoTest;
			this.causaFallimento = causaFallimento;
		}


		public String getNomeTestSuite() {
			return nomeTestSuite;
		}


		public void setNomeTestSuite(String nomeTestSuite) {
			this.nomeTestSuite = nomeTestSuite;
		}


		public String getReleaseDiCreazione() {
			return releaseDiCreazione;
		}


		public void setReleaseDiCreazione(String releaseDiCreazione) {
			this.releaseDiCreazione = releaseDiCreazione;
		}


		public String getLocatoreUtilizzato() {
			return locatoreUtilizzato;
		}


		public void setLocatoreUtilizzato(String locatoreUtilizzato) {
			this.locatoreUtilizzato = locatoreUtilizzato;
		}


		public Boolean getEsitoVerify_Hooks() {
			return esitoVerify_Hooks;
		}


		public void setEsitoVerify_Hooks(Boolean esitoVerify_Hooks) {
			this.esitoVerify_Hooks = esitoVerify_Hooks;
		}


		public Boolean getEsitoTest() {
			return esitoTest;
		}


		public void setEsitoTest(Boolean esitoTest) {
			this.esitoTest = esitoTest;
		}


		public String getCausaFallimento() {
			return causaFallimento;
		}


		public void setCausaFallimento(String causaFallimento) {
			this.causaFallimento = causaFallimento;
		}
		
	
	
	
	
}
