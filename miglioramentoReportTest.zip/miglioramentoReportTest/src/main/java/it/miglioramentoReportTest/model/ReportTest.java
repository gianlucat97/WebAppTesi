package it.miglioramentoReportTest.model;

public class ReportTest {

	
	//Suppongo un solo caso di test per ogni test suite
		//Vedi struttura dati file excel "esiti Test"
		
		private String nomeTestSuite;
		private String nomeTest;
		private String releaseDiCreazione;
		private String locatoreUtilizzato;
		private String esitoVerify_Hooks;
		private String esitoTest;
		private String causaFallimento;
		
		
		public ReportTest() {
			super();
			this.nomeTestSuite = "";
			this.nomeTest = "";
			this.releaseDiCreazione = "";
			this.locatoreUtilizzato = "";
			this.esitoVerify_Hooks = "-";
			this.esitoTest = "";
			this.causaFallimento = "";
		}

		
		

		public ReportTest(String nomeTestSuite, String nomeTest, String releaseDiCreazione, String locatoreUtilizzato,
				String esitoVerify_Hooks, String esitoTest, String causaFallimento) {
			super();
			this.nomeTestSuite = nomeTestSuite;
			this.nomeTest = nomeTest;
			this.releaseDiCreazione = releaseDiCreazione;
			this.locatoreUtilizzato = locatoreUtilizzato;
			this.esitoVerify_Hooks = esitoVerify_Hooks;
			this.esitoTest = esitoTest;
			this.causaFallimento = causaFallimento;
		}




		public String getNomeTest() {
			return nomeTest;
		}




		public void setNomeTest(String nomeTest) {
			this.nomeTest = nomeTest;
		}




		public String getNomeTestSuite() {
			return nomeTestSuite;
		}


		public void setNomeTestSuite(String nomeTestSuite) {
			this.nomeTestSuite = nomeTestSuite;
		}


		public String getReleaseDiCreazione() {
			return releaseDiCreazione;
		}


		public void setReleaseDiCreazione(String releaseDiCreazione) {
			this.releaseDiCreazione = releaseDiCreazione;
		}


		public String getLocatoreUtilizzato() {
			return locatoreUtilizzato;
		}


		public void setLocatoreUtilizzato(String locatoreUtilizzato) {
			this.locatoreUtilizzato = locatoreUtilizzato;
		}


		public String getEsitoVerify_Hooks() {
			return esitoVerify_Hooks;
		}


		public void setEsitoVerify_Hooks(String esitoVerify_Hooks) {
			this.esitoVerify_Hooks = esitoVerify_Hooks;
		}


		public String getEsitoTest() {
			return esitoTest;
		}


		public void setEsitoTest(String esitoTest) {
			this.esitoTest = esitoTest;
		}


		public String getCausaFallimento() {
			return causaFallimento;
		}


		public void setCausaFallimento(String causaFallimento) {
			this.causaFallimento = causaFallimento;
		}
		
	
	
	
	
}
