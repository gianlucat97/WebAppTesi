package it.miglioramentoReportTest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import it.miglioramentoReportTest.function.FunzioniUtili;
import it.miglioramentoReportTest.model.ReportTest;
import it.miglioramentoReportTest.model.TabellaReport;



//NB: è necessario che il file di test sia del tipo:
// nomeTest_Hooks_release_1_0.java
//Dove: nomeTest è facoltativo
//		Hooks, deve essere presente se il test utilizza localizzatori Hooks
//		release_, deve essere presente, seguita dalla versione della release di creazione (per esempio 1_0)


@SpringBootApplication
public class MiglioramentoReportTestApplication {

	
	
	
	//Da linea di comando bisogna passare come args[0] la directory all'interno della quale si trovano i report .txt
	public static void main(String[] args) throws IOException {
		SpringApplication.run(MiglioramentoReportTestApplication.class, args);
		
		
		final Boolean DEBUGGING = false;
		
		TabellaReport tabella = new TabellaReport();
		FunzioniUtili funzioni = new FunzioniUtili();
		
		
		
		
		
		String releaseDiCreazione = new String();
		String locatoreUtilizzato = new String();
		String esitoVerify_Hooks = "-";
		String causaFallimento = "-";
		
		
		
		
		

		//---------------------------------------------------------------------------
		//REPORT DA XML
		//String input_for_args0 = "D:\\CorsoSPRING\\AreaDiLavoro\\miglioramentoReportTest\\src\\main\\resources\\reportFiles";
		//Oppure String input_for_args0 = "D:\CorsoSPRING\AreaDiLavoro\catalogoProdottiBoot\target\surefire-reports";
		File directoryReportXml = new File(args[0]); 
		LinkedList<File> listaReportXml = new LinkedList<File>();
		listaReportXml = funzioni.findAllFilesInFolder(directoryReportXml,"xml");
				
		System.out.println("Vediamo lista file .xml presenti in directory di riferimento");
		int iteraz = 1;
		for(File file: listaReportXml) {
			System.out.println("File numero "+iteraz+"!");
			System.out.println(file);
			iteraz++;
				}
				
		
		for(File fileReport: listaReportXml) {
			BufferedReader reader = new BufferedReader(new FileReader(fileReport));
			
			//Lettura file riga per riga
			String line = reader.readLine();
			int numRiga = 0;
			
			String nomeTestSuite = new String();
			String nomeTest = new String();
			releaseDiCreazione = new String();
			locatoreUtilizzato = new String();
			esitoVerify_Hooks = "-";
			causaFallimento = "-";
			
			Boolean esciDalCiclo= false;
			
			while(line!=null && esciDalCiclo==false) {
				 System.out.println("Riga numero: "+numRiga+"!!!");
				 
			     
			     line = reader.readLine();
			     
			     if(line.equals("</testsuite>")) {
			    	 esciDalCiclo=true;
			     }
			     
			     //System.out.println(line);
			     
			    if(esciDalCiclo==false) {
			     
			     //Estrazione Nome Test Suite e del tipo di locatore
			    
			    	 //Estrazione nome testSuite
			    	 
			    	 //Qui è specificato il nome della testSuite, possiamo quindi estrarlo
			    	 //System.out.println("Vediamo se catturiamo il nome della testSuite");
			    	 //line = line.substring(1); //esclude il primo carattere
			    	 //System.out.println("Valore stringa line: ");
			    	 //System.out.println(line);
			    	 int indiceInizioParola = funzioni.cercaSottoStringa(line, "<testcase name=");
			    	 int indiceFineParola = funzioni.cercaSottoStringa(line," classname=");
			    	 if(indiceInizioParola >=0) {
					    	 System.out.println("La sottostringa test si trova all'indice: "+indiceInizioParola+" della corrente riga");
					    	 
					    	 System.out.println("Vediamo quindi sottostringa di interesse contenente il nome del Test:");
					    	 nomeTest = line.substring(indiceInizioParola+16,indiceFineParola-1);
					    	 System.out.println("Il nome del test trovato è "+nomeTest+" !!!");
					    	 
					    	 //Se ha trovato il nome del test, necessariamente si trova anche quello della test suite
					    	 indiceInizioParola = funzioni.cercaSottoStringa(line, "classname=");
					    	 indiceFineParola = funzioni.cercaSottoStringa(line," time=");
					    	 System.out.println("Vediamo quindi sottostringa di interesse contenente il nome della testSuite:");
					    	 nomeTestSuite = line.substring(indiceInizioParola+11,indiceFineParola-1);
					    	 System.out.println("Il nome della Test Suite trovata è "+nomeTestSuite+" !!!");
					    	 
					    	 ReportTest r = new ReportTest();
					    	 r.setNomeTestSuite(nomeTestSuite);
					    	 r.setNomeTest(nomeTest);
					    	 
					    	 //A partire da nomeTest ricavo il LOCATORE UTILIZZATO
					    	 indiceInizioParola = funzioni.cercaSottoStringa(nomeTest, "Hooks");
					    	 if(indiceInizioParola >= 0) {
					    		 //Allora all'interno del nome del test c'è la parola Hooks
					    		 //Quindi per la convenzione utilizzata il locatore utilizzato sarà test-hooks
					    		 r.setLocatoreUtilizzato("test-hooks");
					    		 r.setEsitoVerify_Hooks("Superato");
					    	 }else if(indiceInizioParola == -1) {
					    		 r.setLocatoreUtilizzato("tradizionale");
					    		 r.setEsitoVerify_Hooks("-");
					    	 }
					    	 
					    	 //A partire da nomeTest ricavo la RELEASE DI CREAZIONE
					    	 indiceInizioParola = funzioni.cercaSottoStringa(nomeTest, "_release_");
					    	 if(indiceInizioParola >= 0) {
					    		 //Allora alla fine del nome del test c'è la parola _release_
					    		 //seguita dalla numero di versione in cui il test è stato creato
					    		 releaseDiCreazione = nomeTest.substring(indiceInizioParola+9);
					    		 r.setReleaseDiCreazione(releaseDiCreazione);
					    		 
					    	 }else if(indiceInizioParola == -1) {
					    		 //se il nome del test non presenta la sottostringa _release_ allora
					    		 //vuol dire che la release di creazione del test è sconosciuta
					    		 r.setReleaseDiCreazione("Sconosciuta");
					    	 }
					    	 
					    	 tabella.aggiungiReport(r);
					    	 
			    	 }
			     
			    	 numRiga++;
			}
		}
		
		
			/*
			
				ReportTest report_test = new ReportTest(nomeTestSuite,releaseDiCreazione,locatoreUtilizzato,esitoVerify_Hooks,esitoTest,causaFallimento);
			
				tabella.aggiungiReport(report_test);
				
				ciSonoAncoraReportTxt = false;	//per dare temporaneamente una condizione di terminazione
				*/
		}
		
		
		
		
		
		
		LinkedList<ReportTest> listaReport = new LinkedList<ReportTest>();
		listaReport = tabella.getListaReport();
		System.out.println("Vediamo la tabella parziale (prima dell'analisi dei txt):");
		tabella.visualizzaTabellaReport();
		System.out.println("Tabella già visualizzata!");
		
		
		
		
		//---------------------TEXT FILE REPORT ------------------------------------------------------

		//String input_for_args = "D:\\CorsoSPRING\\AreaDiLavoro\\miglioramentoReportTest\\src\\main\\resources\\reportFiles";
		File directoryReportTxt = new File(args[0]); 
		LinkedList<File> listaReportTxt = new LinkedList<File>();
		
if(DEBUGGING==false) {
		listaReportTxt = funzioni.findAllFilesInFolder(directoryReportTxt,"txt");
		
		System.out.println("Vediamo lista file .txt presenti in directory di riferimento");
		int iter = 1;
		for(File file: listaReportTxt) {
			System.out.println("File numero "+iter+"!");
			System.out.println(file);
			iter++;
		}
		
		
		for(File fileReport: listaReportTxt) {
			BufferedReader reader = new BufferedReader(new FileReader(fileReport));
			
			//Lettura file riga per riga
			String line = reader.readLine();
			int numRiga = 0;
			
			String nomeTestSuite = new String();
			String nomeTest = new String();
			releaseDiCreazione = new String();
			locatoreUtilizzato = new String();
			esitoVerify_Hooks = "-";
			causaFallimento = "-";
			
			while(line!=null) {
				 System.out.println("Riga numero: "+numRiga+"!!!");
				 
			     
			     line = reader.readLine();
			     
			     System.out.println(line);
			     String numeroErrors = "0";
			     String numeroFailures = "0";
			     
			     if(numRiga==0) {
			    	 int indiceInizioParola = funzioni.cercaSottoStringa(line, "Test set:");
			    	 nomeTestSuite = line.substring(indiceInizioParola+10);
			     }
			     
			     if(numRiga==2) {
			    	 //Estrazione esito test
			    	 System.out.println("Vediamo se catturiamo il numero di Errors riscontrati");
			    	 //line = line.substring(1); //esclude il primo carattere
			    	 System.out.println("Valore stringa line: ");
			    	 System.out.println(line);
			    	 //Cerca numero di Errors
			    	 int indiceInizioParola = funzioni.cercaSottoStringa(line, "Errors:"); //cerca 'Errors:' in line
			    	 int indiceFineParola = funzioni.cercaSottoStringa(line, ", Skipped:");
			    	 System.out.println("La sottostringa 'Errors:' si trova all'indice: "+indiceInizioParola+" della corrente riga");
			    	 
			    	 System.out.println("Vediamo quindi sottostringa di interesse contenente il numero di Errors della testSuite:");
			    	 numeroErrors = line.substring(indiceInizioParola+8,indiceFineParola);
			    	 System.out.println(numeroErrors);
			    	 System.out.println("Vediamo convertendolo ad intero...");
			    	 
			    	 
			    	 System.out.println(Integer.parseInt(numeroErrors));
			    	 
			    	 
			    	 //Cerca numero di Failures
			    	 indiceInizioParola = funzioni.cercaSottoStringa(line, "Failures:");
			    	 indiceFineParola = funzioni.cercaSottoStringa(line, ", Errors:");
			    	 System.out.println("La sottostringa 'Failures:' si trova all'indice: "+indiceInizioParola+" della corrente riga");
			    	 
			    	 System.out.println("Vediamo quindi sottostringa di interesse contenente il numero di Errors della testSuite:");
			    	 numeroFailures = line.substring(indiceInizioParola+10,indiceFineParola);
			    	 System.out.println(numeroFailures);
			    	 System.out.println("Vediamo convertendolo ad intero...");
			    	 
			    	 
			    	 System.out.println(Integer.parseInt(numeroFailures));
			    	 
			    	 
			    	 
			    	 
			    	 if(Integer.parseInt(numeroErrors)==0 || Integer.parseInt(numeroFailures)==0) {
			    		 //Non ci sono test che falliscono nell'intera test suite
			    		 for(ReportTest r: listaReport) {
			    			 if(r.getNomeTestSuite().equals(nomeTestSuite)) {
			    				 r.setEsitoTest("Superato");
			    				 r.setCausaFallimento("-");
			    			 }
			    			 
			    		 }
			    		 
			    	 }
			     }
			     
			     
			     if(numRiga>2 && line!=null) {
			    	 
			    	//Siamo alla ricerca di test che hanno un failure o un error
			    	
			    	 int indiceParolaFailure = funzioni.cercaSottoStringa(line, "<<< FAILURE!"); //cerca 'Errors:' in line
			    	 int indiceParolaError = funzioni.cercaSottoStringa(line, "<<< ERROR!"); //cerca 'Errors:' in line
			    	 if(indiceParolaFailure>0) {
			    		 //Allora nella riga corrente c'è un test che fallisce
			    		 System.out.println("In questa line un test fallisce:");
			    		 System.out.println(line);
			    		 
			    		 //Estrarre nome del test
			    		 int indiceFineParola = funzioni.cercaSottoStringa(line, "  Time elapsed:");
			    		 nomeTest = line.substring(0,indiceFineParola);
			    		 System.out.println("Il test che fallisce è:");
			    		 System.out.println(nomeTest);
			    		 
			    		 int numTest=1;
			    		 for(ReportTest r: listaReport) {
			    			 System.out.println("Quando c'è un Failure!!!");
			    			 System.out.println("CHECK "+numTest);
			    			 numTest++;
			    			 System.out.println("nome test iterante: "+r.getNomeTest()+"  , nome test da eguagliare: "+nomeTest);
			    			 System.out.println("nome test suite iterante: "+r.getNomeTestSuite()+"  , nome test suite da eguagliare: "+nomeTestSuite);
			    			 if(r.getNomeTest().equals(nomeTest) && r.getNomeTestSuite().equals(nomeTestSuite)) {
			    				 r.setEsitoTest("Presenta Failures");
			    				 r.setCausaFallimento("Causa di fallimento obsolescenza/fragilità (specificare a mano)");
			    				 System.out.println("Sono DENTRO AL FAILURE!!!!!!!!!!!!!!!!!");
			    			 }
			    		 }
			    		 
			    		 
			    	 }else if(indiceParolaError>0) {
			    		//Allora nella riga corrente c'è un test che presenta un errore
			    		 System.out.println("In questa line un test presenta un errore:");
			    		 System.out.println(line);
			    		 
			    		 
			    		//Estrarre nome del test
			    		 int indiceFineParola = funzioni.cercaSottoStringa(line, "  Time elapsed:");
			    		 nomeTest = line.substring(0,indiceFineParola);
			    		 System.out.println("Il test che presenta un errore è:");
			    		 System.out.println(nomeTest);
			    		 
			    		 int numTest=1;
			    		 for(ReportTest r: listaReport) {
			    			 System.out.println("Quando c'è un Error!!!");
				    		 System.out.println("CHECK "+numTest);
			    			 numTest++;
			    			 System.out.println("nome test iterante: "+r.getNomeTest()+"  , nome test da eguagliare: "+nomeTest);
			    			 System.out.println("nome test suite iterante: "+r.getNomeTestSuite()+"  , nome test suite da eguagliare: "+nomeTestSuite);
			    			 if(r.getNomeTest().equals(nomeTest) && r.getNomeTestSuite().equals(nomeTestSuite)) {
			    				 r.setEsitoTest("Presenta un Error");
			    				 r.setCausaFallimento("Causa di errore obsolescenza/fragilità (specificare a mano)");
			    				 System.out.println("Sono DENTRO ALL'ERROR!!!!!!!!!!!!!!!!!");
			    			 }
			    		 }
			    		 
			    		 
			    		 
			    	 }
			    	 
			    	 
			    	 
			    	 
			     }
			     
			     
			     
			     numRiga++;
			     
			     
			     
		}
		
		
				
		}
		
		//Qui vuol dire che abbiamo finito con tutti i file, sia con i txt che con gli xml
		
		//Stampa a video di tutti i report aggiunti nella tabella
		
		
		System.out.println("Vediamo la tabella iniziale:");
		tabella.visualizzaTabellaReport();
		System.out.println("Tabella già visualizzata!");
		
		tabella.setListaReport(listaReport);
		System.out.println("Vediamo la tabella FINALE:");
		tabella.visualizzaTabellaReport();
		System.out.println("Tabella già visualizzata!");
		
		//NB: Adesso l'unica cosa da fare è aggiungere l'esito superato
		
		//Crea File Excel a partire da tabellaReport
		funzioni.creaFileExcel(tabella,args[1]);
		
		
		
		
		
		
		
}	//Fine if per debugging (viene eseguito solo se DEBUGGING=false
		
		
		
		
		
		
	}//chiude main

}//chiude classe file
