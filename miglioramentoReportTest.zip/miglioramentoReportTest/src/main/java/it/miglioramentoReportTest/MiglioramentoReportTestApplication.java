package it.miglioramentoReportTest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import it.miglioramentoReportTest.function.FunzioniUtili;
import it.miglioramentoReportTest.model.ReportTest;
import it.miglioramentoReportTest.model.TabellaReport;



//NB: è necessario che il file di test sia del tipo:
// nomeTest_Hooks_release_1_0.java
//Dove: nomeTest è facoltativo
//		Hooks, deve essere presente se il test utilizza localizzatori Hooks
//		release_, deve essere presente, seguita dalla versione della release di creazione (per esempio 1_0)


@SpringBootApplication
public class MiglioramentoReportTestApplication {

	//Da linea di comando bisogna passare come args[0] la directory all'interno della quale si trovano i report .txt
	public static void main(String[] args) throws IOException {
		SpringApplication.run(MiglioramentoReportTestApplication.class, args);
		
		
		
		
		TabellaReport tabella = new TabellaReport();
		FunzioniUtili funzioni = new FunzioniUtili();
		
		Boolean ciSonoAncoraReportTxt = true;
		
		
		
		
		String nomeTestSuite = new String();
		String releaseDiCreazione = new String();
		String locatoreUtilizzato = new String();
		Boolean esitoVerify_Hooks = false;
		Boolean esitoTest = false;	//inizializzato a test fallito
		String causaFallimento = "-";
		

		//String input_for_args = "D:\\CorsoSPRING\\AreaDiLavoro\\miglioramentoReportTest\\src\\main\\resources\\reportTxt";
		File directoryReportTxt = new File(args[0]); 
		LinkedList<File> listaReportTxt = new LinkedList<File>();
		listaReportTxt = funzioni.findAllFilesInFolder(directoryReportTxt);
		
		System.out.println("Vediamo lista file .txt presenti in directory di riferimento");
		int iter = 1;
		for(File file: listaReportTxt) {
			System.out.println("File numero "+iter+"!");
			System.out.println(file);
			iter++;
		}
		
		
		for(File fileReport: listaReportTxt) {
			BufferedReader reader = new BufferedReader(new FileReader(fileReport));
			
			//Lettura file riga per riga
			String line = reader.readLine();
			int numRiga = 0;
			
			nomeTestSuite = new String();
			releaseDiCreazione = new String();
			locatoreUtilizzato = new String();
			esitoVerify_Hooks = false;
			esitoTest = false;	//inizializzato a test fallito
			causaFallimento = "-";
			
			while(line!=null) {
				 System.out.println("Riga numero: "+numRiga+"!!!");
				 
			     
			     line = reader.readLine();
			     
			     System.out.println(line);
			     
			    
			     
			     //Estrazione Nome Test Suite e del tipo di locatore
			     if(numRiga==0) {
			    	 //Estrazione nome testSuite
			    	 
			    	 //Qui è specificato il nome della testSuite, possiamo quindi estrarlo
			    	 System.out.println("Vediamo se catturiamo il nome della testSuite");
			    	 //line = line.substring(1); //esclude il primo carattere
			    	 System.out.println("Valore stringa line: ");
			    	 System.out.println(line);
			    	 int indiceParola = funzioni.cercaSottoStringa(line, ".test."); //cerca test in line
			    	 System.out.println("La sottostringa test si trova all'indice: "+indiceParola+" della corrente riga");
			    	 
			    	 System.out.println("Vediamo quindi sottostringa di interesse contenente il nome della testSuite:");
			    	 nomeTestSuite = line.substring(indiceParola+6);
			    	 System.out.println(nomeTestSuite);
			    	 
			    	 
			    	 //Estrazione nome locatore
			    	 System.out.println("Valore stringa line: ");
			    	 System.out.println(line);
			    	 indiceParola = funzioni.cercaSottoStringa(line, "Hooks");
			    	 System.out.println("La sottostringa cercata si trova all'indice: "+indiceParola+" della corrente riga");
			    	 if(indiceParola >= 0) {
			    	 locatoreUtilizzato = "test-hooks";
			    	 esitoVerify_Hooks = true;
			    	 }else {
			    		 locatoreUtilizzato = "tradizionale";
			    		 esitoVerify_Hooks = false;
			    	 }
			    	 System.out.println("LOCATORE UTILIZZATO: "+locatoreUtilizzato+" !!!");
			    	 
			    	 
			    	 
			    	 //Estrazione release di creazione
			    	 System.out.println("Valore stringa line: ");
			    	 System.out.println(line);
			    	 indiceParola = funzioni.cercaSottoStringa(line, "release_");
			    	 System.out.println("La sottostringa cercata si trova all'indice: "+indiceParola+" della corrente riga");
			    	 System.out.println("Vediamo quindi sottostringa di interesse contenente la release di creazione della testSuite:");
			    	 releaseDiCreazione = line.substring(indiceParola+8);
			    	 System.out.println(releaseDiCreazione);
			    	 
			     }
			     
			     
			     if(numRiga==2) {
			    	 //Estrazione esito test
			    	 System.out.println("Vediamo se catturiamo il numero di Errors riscontrati");
			    	 //line = line.substring(1); //esclude il primo carattere
			    	 System.out.println("Valore stringa line: ");
			    	 System.out.println(line);
			    	 int indiceInizioParola = funzioni.cercaSottoStringa(line, "Errors:"); //cerca 'Failures:' in line
			    	 int indiceFineParola = funzioni.cercaSottoStringa(line, ", Skipped:");
			    	 System.out.println("La sottostringa 'Errors:' si trova all'indice: "+indiceInizioParola+" della corrente riga");
			    	 
			    	 System.out.println("Vediamo quindi sottostringa di interesse contenente il numero di Errors della testSuite:");
			    	 String numeroErrors = line.substring(indiceInizioParola+8,indiceFineParola);
			    	 System.out.println(numeroErrors);
			    	 System.out.println("Vediamo convertendolo ad intero...");
			    	 
			    	 
			    	 System.out.println(Integer.parseInt(numeroErrors));
			    	 
			    	 if(Integer.parseInt(numeroErrors)==0) {
			    		 esitoTest = true;
			    		 causaFallimento = "-";
			    	 }else {
			    		 esitoTest = false;
			    		 causaFallimento = "Causa fallimento test da aggiungere a mano (Obsolescenza/Fragilità)";
			    	 }
			    	 
			    	 System.out.println("Valore Causa Fallimento test: "+causaFallimento+" !!!");
			    	 
			     }
			     
			     
			     numRiga++;
		}
		
		
			
			
				ReportTest report_test = new ReportTest(nomeTestSuite,releaseDiCreazione,locatoreUtilizzato,esitoVerify_Hooks,esitoTest,causaFallimento);
			
				tabella.aggiungiReport(report_test);
				
				ciSonoAncoraReportTxt = false;	//per dare temporaneamente una condizione di terminazione
		}
		
		//Qui vuol dire che abbiamo finito con tutti i file
		
		//Stampa a video di tutti i report aggiunti nella tabella
		LinkedList<ReportTest> listaReport = new LinkedList<ReportTest>();
		listaReport = tabella.getListaReport();
		tabella.visualizzaTabellaReport();
		
		
		//Crea File Excel a partire da tabellaReport
		funzioni.creaFileExcel(tabella,"tabellaReportTest");
		
		
	}

}
