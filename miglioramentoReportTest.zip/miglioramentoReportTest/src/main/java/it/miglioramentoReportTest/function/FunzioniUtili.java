package it.miglioramentoReportTest.function;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import it.miglioramentoReportTest.model.ReportTest;
import it.miglioramentoReportTest.model.TabellaReport;

public class FunzioniUtili {

	// definiamo la stringa in cui effettuare la ricerca
    // e la sottostringa da ricercare
    
	public FunzioniUtili() {
		super();
	}
	
	
	
	public int cercaSottoStringa(String stringa, String sottostringa){
	
    int indiceMatching = 0; //indice al quale inizia la sottostringa cercata

    // al momento non è stata effettuata alcuna ricerca
    // ne conseguito alcun risultato 		
    Boolean cerca = false;

    // calcoliamo lunghezza di stringa e sottostringa
    // la differenza sarà condizione di terminazione per il ciclo for
    int max = (stringa.length() - sottostringa.length());

    // ricerchiamo la sottostringa ciclando il contenuto di quest'ultima
    test:
    for (int i = 0; i <= max; i++) {
      int n = sottostringa.length();
      int j = i;
      int k = 0;
      while (n-- != 0) {
        if (stringa.charAt(j++) != sottostringa.charAt(k++)) {
          continue test;
        }
      }

      // a questo punto è stata effettuata una ricerca
      // sarà possibile produrre un output			
      cerca = true;
      indiceMatching = i; //indice in cui avviene il matching
      break test;
    }

    // stampiamo l'output sulla base dell'esito della ricerca		
    System.out.println(cerca ? "Tovata" : "Non Trovata");
	
    if(cerca==true) {
    	
    	System.out.println("La sottostringa cercata inizia all'indice: "+indiceMatching);
    	
    }else {
    	indiceMatching = -1;
    }
    
    
    return indiceMatching;
	
	}

	
	public LinkedList<File> findAllFilesInFolder(File folder) {
		LinkedList<File> listaFiletxt = new LinkedList<File>();
		
		for (File file : folder.listFiles()) {
			if (!file.isDirectory()) {
				System.out.println(file.getName());
				if(file.getName().endsWith(".txt")) {
				listaFiletxt.add(file);
				}
			} else {
				findAllFilesInFolder(file);
			}
		}
		return listaFiletxt;
	}
	
	
	
	public void creaFileExcel(TabellaReport tabella, String fileDaCreare) {
		
		 	XSSFWorkbook workbook = new XSSFWorkbook();
	        XSSFSheet spreadsheet = workbook.createSheet("UTENTI");
	        Map<String, Object[]> empinfo = new TreeMap<>();
	        empinfo.put("1", new Object[]{"TEST SUITE", "RELEASE DI CREAZIONE", "LOCATORE", "ESITO VERIFY-HOOKS", "ESITO TEST","CAUSA FALLIMENTO"});
	        
	        int numElem = tabella.getNumElem();
	        LinkedList<ReportTest> lista = tabella.getListaReport();
	        for (int i = 2; i < numElem+2; i++) {
	        	ReportTest r = lista.pop();
	            empinfo.put(String.valueOf(i), new Object[]{
	               r.getNomeTestSuite(), r.getReleaseDiCreazione(),
	                r.getLocatoreUtilizzato(), r.getEsitoVerify_Hooks().toString(), r.getEsitoTest().toString(),r.getCausaFallimento()
	            });
	        }
	        Set keyid = empinfo.keySet();
	        int rowid = 0;
	        XSSFRow row;
	        for (Object key : keyid) {
	            row = spreadsheet.createRow(rowid++);
	            Object[] objectArr = empinfo.get(key);
	            int cellid = 0;
	            for (Object obj : objectArr) {
	                Cell cell = row.createCell(cellid++);
	                cell.setCellValue((String) obj);
	            }
	        }
	        try (FileOutputStream out = new FileOutputStream(new File(fileDaCreare+".xlsx"))) {
	            workbook.write(out);
	        } catch (FileNotFoundException ex) {
	            System.out.println(ex.getMessage());
	        } catch (IOException ex) {
	            System.out.println(ex.getMessage());
	        }
		
		
		
	}
	
}
